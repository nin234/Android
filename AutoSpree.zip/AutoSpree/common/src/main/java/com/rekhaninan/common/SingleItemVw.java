package com.rekhaninan.common;

import android.app.Activity;

/**
 * Created by nin234 on 8/25/16.
 */
public class SingleItemVw extends Activity
{

}
